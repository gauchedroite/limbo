/// <reference path="typings/tsd.d.ts" />
var React = require("react");
var ReactDom = require("react-dom");
var editor_1 = require("./app/editor");
require("./css/app.less");
ReactDom.render(React.createElement(editor_1.default, null), document.getElementById("id-wrapper"));
//# sourceMappingURL=app.js.map