"use strict";
var Api = (function () {
    function Api(root) {
        this.root = root;
    }
    Api.prototype.fetch = function (command, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    var text = xhr.responseText;
                    var obj = JSON.parse(text);
                    console.log(obj);
                    callback(obj);
                }
                else if (xhr.status == 404) {
                    var text = xhr.responseText;
                    var obj = JSON.parse(text);
                    console.log(obj);
                    callback(obj);
                }
            }
        };
        xhr.open("GET", this.root + command, true);
        xhr.send();
    };
    return Api;
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = Api;
//# sourceMappingURL=api.js.map