var Freezer = require("../freezer/Freezer");
var Utils = require("./utils");
var state = Utils.store("appState") || {
    game: {},
    chapter: {},
    scene: {},
    status: "N O T   L O A D E D"
};
module.exports = new Freezer(state);
//# sourceMappingURL=state.js.map