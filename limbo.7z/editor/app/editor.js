var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var React = require("react");
var react_router_1 = require("react-router");
var scene_1 = require("./components/scene");
var actor_1 = require("./components/actor");
var location_1 = require("./components/location");
var State = require("./state");
require("./reactions");
var EditorApp = (function (_super) {
    __extends(EditorApp, _super);
    function EditorApp() {
        _super.apply(this, arguments);
    }
    EditorApp.prototype.render = function () {
        return (React.createElement(react_router_1.Router, null, React.createElement(react_router_1.Route, {"path": "/", "component": Root}, React.createElement(react_router_1.IndexRoute, {"component": actor_1.default}), React.createElement(react_router_1.Route, {"path": "actors", "component": actor_1.default}), React.createElement(react_router_1.Route, {"path": "locations", "component": location_1.default}), React.createElement(react_router_1.Route, {"path": "scenes", "component": scene_1.default}))));
    };
    return EditorApp;
})(React.Component);
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = EditorApp;
var Root = (function (_super) {
    __extends(Root, _super);
    function Root() {
        _super.call(this);
        State.trigger("scene:fetch", 0);
    }
    Root.prototype.render = function () {
        var state = State.get();
        return (React.createElement("div", null, React.createElement("nav", null, React.createElement("ul", null, React.createElement("li", null, React.createElement(react_router_1.Link, {"to": "/actors"}, "Actors")), React.createElement("li", null, React.createElement(react_router_1.Link, {"to": "/locations"}, "Locations")), React.createElement("li", null, React.createElement(react_router_1.Link, {"to": "/scenes"}, "Scenes")))), React.cloneElement(this.props.children, { appState: state })));
    };
    Root.prototype.componentDidMount = function () {
        var _this = this;
        State.on("update", function () {
            _this.forceUpdate();
        });
    };
    return Root;
})(React.Component);
//# sourceMappingURL=editor.js.map