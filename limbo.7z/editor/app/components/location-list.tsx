
import React = require("react");
import State = require( "../state");
import { IProps, IState, IScene } from "../i-state";


export default class LocationList extends React.Component<IProps, any> {
    render() {
        return (
            <h1>L O C A T I O N</h1>
        );
    }
}
