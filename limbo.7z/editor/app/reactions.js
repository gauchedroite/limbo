var State = require("./state");
var api_1 = require("./api");
var api = new api_1.default("http://localhost:1337/api");
State.on("scene:fetch", function (id) {
    State.get().set({ status: "L O A D I N G" });
    api.fetch("/scenes/" + id, function (payload) {
        if (payload.error) {
            State.get().set({ status: "[" + payload.error + "]" });
            return;
        }
        State.get()
            .set("scene", payload.data)
            .set("status", "L O A D E D");
    });
});
State.on("scene:set.heading", function (text) {
    State.get().scene.set("heading", text);
});
//# sourceMappingURL=reactions.js.map