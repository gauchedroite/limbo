
declare var Utils: any;

export = Utils;
