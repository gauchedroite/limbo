# limbo - public
The game!

Requirements
---
You will need these tools installed globally
```
npm install -g gulp
npm install -g tsd
```

Installation
---
```
npm install
tsd reinstall -so
```

`tsd` will install all the required TypeScript definition files for the libraries in `typings`. 
It will also create `typings\tsd.d.ts` that can be included in TypeScript files.

