/// <reference path="typings/tsd.d.ts" />
"use strict";
var mongodb = require("mongodb");
var private_1 = require("./private");
var db;
mongodb.MongoClient.connect(private_1.uri, function (err, mdb) {
    if (err) {
        console.log(err.message);
        throw err;
    }
    db = mdb;
}.bind(this));
function abort(err, callback) {
    console.log(err);
    callback(err, null);
}
function getChapters(callback) {
    db.collection("chapter", function (err, chaps) {
        if (err)
            return abort(err, callback);
        chaps.find().toArray(function (err, objs) {
            if (err)
                return abort(err, callback);
            callback(null, objs);
        });
    });
}
exports.getChapters = getChapters;
function getChapter(id, callback) {
    db.collection("chapter", function (err, chaps) {
        if (err)
            return abort(err, callback);
        chaps.findOne({ _id: Number(id) }, function (err, obj) {
            if (err)
                return abort(err, callback);
            callback(null, obj);
        });
    });
}
exports.getChapter = getChapter;
function getActors(callback) {
    db.collection("actor", function (err, acts) {
        if (err)
            return abort(err, callback);
        acts.find().toArray(function (err, objs) {
            if (err)
                return abort(err, callback);
            callback(null, objs);
        });
    });
}
exports.getActors = getActors;
function getActor(id, callback) {
    db.collection("actor", function (err, acts) {
        if (err)
            return abort(err, callback);
        acts.findOne({ _id: Number(id) }, function (err, obj) {
            if (err)
                return abort(err, callback);
            callback(null, obj);
        });
    });
}
exports.getActor = getActor;
function getLocations(callback) {
    db.collection("location", function (err, acts) {
        if (err)
            return abort(err, callback);
        acts.find().toArray(function (err, objs) {
            if (err)
                return abort(err, callback);
            callback(null, objs);
        });
    });
}
exports.getLocations = getLocations;
function getLocation(id, callback) {
    db.collection("location", function (err, acts) {
        if (err)
            return abort(err, callback);
        acts.findOne({ _id: Number(id) }, function (err, obj) {
            if (err)
                return abort(err, callback);
            callback(null, obj);
        });
    });
}
exports.getLocation = getLocation;
function getScenes(callback) {
    db.collection("scene", function (err, acts) {
        if (err)
            return abort(err, callback);
        acts.find().toArray(function (err, objs) {
            if (err)
                return abort(err, callback);
            callback(null, objs);
        });
    });
}
exports.getScenes = getScenes;
function getScene(id, callback) {
    db.collection("scene", function (err, acts) {
        if (err)
            return abort(err, callback);
        acts.findOne({ _id: Number(id) }, function (err, obj) {
            if (err)
                return abort(err, callback);
            callback(null, obj);
        });
    });
}
exports.getScene = getScene;
//# sourceMappingURL=db.js.map