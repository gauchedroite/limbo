exports.uri = "mongodb://admin:cheval@ds053788.mongolab.com:53788/gauchedroite";
//# sourceMappingURL=private.js.map