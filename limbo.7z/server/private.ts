
export const uri = "mongodb://admin:cheval@ds053788.mongolab.com:53788/gauchedroite";
