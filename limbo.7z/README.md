# limbo
Interactive adventure game. TypeScript, node, mongodb, freezer-js.

Installation
---
The installation instructions are in each project's folder.